﻿#Make Quick HTMLTag shortcuts
$tempscriptname = $MyInvocation.MyCommand.Definition
$TagsFile = $tempscriptname -replace '\.ps1','_Tags.txt'
$TagsFileObj = gi $TagsFile
#Update tags file
if ($TagsFileObj.LastWriteTime.adddays(30) -lt (get-date))
{
    $Taglist = New-Object System.Collections.ArrayList
    (curl -UseBasicParsing https://www.w3schools.com/TAGs/ref_byfunc.asp).Content -split '\<|\>' -match '\&lt;' | %{$_ -split '\&lt;' | select -last 1| %{$_ -split '\&gt;' | select -First 1} }|?{$_} | %{$Taglist.add($_)} > $null
    ((1..6)|%{"H$_"}) | %{$Taglist.add($_)} > $null
    if ($Taglist.count -gt 30)
    {
        $TagList | sort -Unique | Out-File -Encoding utf8 -FilePath $TagsFile -Force
    }
    
}
(gc $TagsFile) -split '\s|\n' | ?{$_} | %{
    $TagName=$_
    $T=@"
function _$TagName (`$TagData,`$innerHTML,[switch]`$NoTerminatingTag) {
    '<$TagName ' + (.{
    if (`$TagData) {if (`$TagData.GetType().Name -eq 'ScriptBlock') {`$TagData=. `$TagData}}
    if (`$innerHTML) {if (`$innerHTML.GetType().Name -eq 'ScriptBlock') {`$innerHTML=. `$innerHTML}}
    
    if ( `$TagData -ne `$null )
    {
        . {
            if ( `$TagData.gettype().name -eq 'scriptblock' ) 
            {
                . `$TagData
            } 
            ELSE 
            {
                `$TagData
            }
        }
    }
    })+'>'+(.{
    if ( `$InnerHTML -ne `$null )
    {
        . {
            if (`$InnerHTML.gettype().name -eq 'scriptblock')
            {
                . `$InnerHTML
            }
            ELSE
            {
                `$InnerHTML
            }
        }
    }
    })+(.{if (-not `$NoTerminatingTag){'</$TagName>'}})
}
"@
    $SB=[scriptblock]::Create($T)
    . $SB
}

