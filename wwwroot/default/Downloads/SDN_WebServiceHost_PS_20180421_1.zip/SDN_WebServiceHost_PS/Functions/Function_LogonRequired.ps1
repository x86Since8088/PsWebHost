﻿Function LogonRequired {
    param (
        $HTTPSListenerContext,
        [switch]$GetApprovedArgs,
        $AppArguments
    )
    if ($GetApprovedArgs) {return ('Logon','Logoff','Navigate','ParamReset','ParamName','ParamAdd','ParamRemove')}

    if ($ActiveLogon)
    {
        $ActiveLogon
    }

    get-member -InputObject $global:context.Request
    $global:context.Request|fl
    Write_Tag -Tag form -TagData 'action="Home" method="post" method' -Content (&{
          Write_Tag -Tag input -TagData "type=""hidden"" name=""App"" value=""Logon""" -NoTerminatingTag
          'UserName:<br>'
          Write_Tag -Tag input -TagData "type=""text"" name=""UserName"" value=""$($UserName -join ',')""" -NoTerminatingTag
          '<br>'
          'Password:<br>'
          Write_Tag -Tag input -TagData "type=""password"" name=""Password"" value=""$($Password -join ',')""" -NoTerminatingTag
          '<br>'
          Write_Tag -Tag input -TagData 'type="submit" value="Submit"' -NoTerminatingTag
  
    })
    $arguments
    ""
    $UserProfile
    ""
    $global:context
    ""
    $global:listener
}