﻿param (
    $HTTPSListenerContext,
    [switch]$GetApprovedArgs,
    $AppArguments
)
if ($GetApprovedArgs) {return ('Logon','Logoff','Navigate','ParamReset','ParamName','ParamAdd','ParamRemove')}

. "$Global:ScriptFolder\Apps\Reload Functions.ps1"|out-null
$UserName = $arguments   | ?{$_.name -eq 'UserName'} | %{$_.Value -split "\s|`n|,"} | ?{$_}
$Password = $arguments   | ?{$_.name -eq 'Password'} | %{$_.Value -split "\s|`n|,"} | ?{$_}
$AuthSource = $arguments | ?{$_.name -eq 'AuthSource'} | %{$_.Value -split "\s|`n|,"} | ?{$_}
$UserSession = Get_UserSession
if($username -and $Password)
{
    if     ($UserName -match '\\') {$S=$UserName -split '\\' |?{$_ -match '[a-z0-9]'};$LogonDomain = $S| select -First 1;$LogonUserName = $S| select -Last  1}
    ELSEif ($UserName -match '@')  {$S=$UserName -split '\\' |?{$_ -match '[a-z0-9]'};$LogonDomain = $S| select -Last  1;$LogonUserName = $S| select -First 1}
    Switch ($Authsource)
    {
        "AD" {
            $ADUserAccount = get-aduser -Identity $LogonUserName
        }
        default {
            
        }
        
    }
    New-Object psobject -Property @{User=$UserName;AuthSource=$Authsource} 
}
ELSE
{
Write_Tag -Tag form -TagData 'Name="AuthForm" action="Home" method="post"' -Content (&{
      Write_Tag -Tag input -TagData "type=""hidden"" name=""App"" value=""Logon""" -NoTerminatingTag
      'UserName:<br>'
      Write_Tag -Tag input -TagData "type=""text"" name=""UserName"" value=""$($UserName -join ',')""" -NoTerminatingTag
      '<br>'
      'Password:<br>'
      Write_Tag -Tag input -TagData "type=""password"" name=""Password"" value=""$($Password -join ',')""" -NoTerminatingTag
      '<br>'
      Write_Tag -Tag input -TagData "type=""hidden"" name=""AuthSource"" value=""$($Password -join ',')""" -NoTerminatingTag
      Write_Tag -Tag input -TagData 'type="submit" value="AD"        onClick="document.AuthForm.myinput.value = ''AD''"' -NoTerminatingTag
      Write_Tag -Tag input -TagData 'type="submit" value="Google"    onClick="document.AuthForm.myinput.value = ''Google''"' -NoTerminatingTag
      Write_Tag -Tag input -TagData 'type="submit" value="O365"      onClick="document.AuthForm.myinput.value = ''O365''"' -NoTerminatingTag
      Write_Tag -Tag input -TagData 'type="submit" value="LinkedIn"  onClick="document.AuthForm.myinput.value = ''LinkedIn''"' -NoTerminatingTag
})
}

get-member -InputObject $global:context.Request
$global:context.Request|fl



$arguments
""
"Profile"
Get_Profile
""
"Get_LogonInformation"
Get_LogonInformation
""
$UserProfile|?{$_} | %{
    $O = $_
    get-member -in $O -membertype properties | ?{$_.name} |%{
    "UserProfile." + $_.name
    $O.($_.name)| write_htable
    }
}
""
$O = $Global:context.request
get-member -in $O -membertype properties | ?{$_.name} |%{
"Context.request." + $_.name
$O.($_.name)| write_htable
}


""

$O = $global:listener
get-member -in $O -membertype properties | ?{$_.name} |%{
"Listener." + $_.name
$O.($_.name)| write_htable
}