﻿param (
    $HTTPSListenerContext,
    [switch]$GetApprovedArgs,
    $AppArguments
)
if ($GetApprovedArgs) 
{
    return ('Run')
}
$AppArguments
    "<H1>Reloading Functions</H1>"
    gci "$Global:ScriptFolder\Functions" *.ps1
    gci "$Global:ScriptFolder\Functions" *.ps1 | %{$_.fullname}
